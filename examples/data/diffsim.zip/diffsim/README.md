# DiffSim Example Data

This directory contains the compact real test-data subset used by the DiffSim
examples. The notebooks and scripts use local sample indices only:

- `case1_geomodeling`: local sample indices `0..7`
- `case2_muddrape`: local sample indices `0..7`
- `case3_la3d`: local sample indices `0..7`

The local example datasets are intentionally compact, so the notebooks and
scripts can run without referring back to external dataset numbering.
